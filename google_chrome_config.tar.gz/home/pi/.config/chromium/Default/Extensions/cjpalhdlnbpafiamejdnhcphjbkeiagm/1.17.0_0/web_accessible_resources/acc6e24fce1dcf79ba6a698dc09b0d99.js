(function() {
	window._gaq = window._gaq || {
		push: function() {
			;
		}
	};
})();
